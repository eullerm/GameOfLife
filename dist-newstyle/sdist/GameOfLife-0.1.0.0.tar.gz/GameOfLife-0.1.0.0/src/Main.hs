module Main where
import Data.List
import Data.List.Split
import Data.Strings
import Data.Typeable
import Data.Char (ord, chr)

width, height :: Int
width = 80 -- tam da linha
height = 24 -- tam da coluna

type Cells = [Pos] -- coordenadas das células

data Cell = V | M | Z deriving Show -- Define como uma célula pode ser

{- rightList (x:y:rest) = (x,y) : rightList (y:rest)
rightList _ = []

right m = m >>= rightList

swap (x,y) = (y,x)
co direction = map swap . direction
left = co right

down = right . transpose
up   = co down

downRight (xs:ys:rest) = zip xs (drop 1 ys) ++ downRight (ys:rest)
downRight _            = []
upLeft = co downRight

upRight  = downRight . reverse
downLeft = co upRight

allDirections = [right, left, up, down,
                 downRight, upLeft, upRight, downLeft]
neighbors m = allDirections >>= ($m)  -}

-- Retorna a posição de um elemento x numa lista
positions  :: Eq a => a -> [a] -> [Int]
positions x = map fst . filter ((x ==) . snd) . zip [0..]

-------------------------------------------------------------

type Pos = (Int,Int) -- coluna, linha
type Row = [(Pos, String)]
type Matrix = [Row]

-- Cria a matriz
initMatrix :: [Int] -> IO Matrix
initMatrix [1,width] = 
  do 
    line <- getLine
    let lineSplit = words line -- Splita a linha de input do usuario
    let exactSize = getExactSize lineSplit 1 width
    return [exactSize]
initMatrix [height,width] =
  do
    line <- getLine
    let lineSplit = words line -- Splita a linha de input do usuario
    let exactSize = getExactSize lineSplit height width
    nextLine <- initMatrix [(height-1), width]
    return (exactSize:nextLine)

-- Calcula o tamanho exato que cada vetor da matriz precisa ter
getExactSize :: [String] -> Int -> Int -> Row
getExactSize lineSplit row columns= 
  do
    let vetRow = take columns (repeat row)
    let vetColumn = [1..columns]
    let pos = zip vetRow vetColumn 
    let exactSize = take columns lineSplit
    let incrementSize = lineSplit ++ take (columns - (length lineSplit)) (repeat "M")
    if(length lineSplit == columns)
      then (zip pos exactSize)
    else if(length lineSplit < columns)
      then (zip pos incrementSize)
    else
      zip pos exactSize

-- Imprime a matriz
printMatrix :: Matrix -> IO ()
printMatrix (vet:[]) = 
  do 
    printValue vet
printMatrix (vet:rest) =
  do 
    printValue vet
    printMatrix rest

-- Imprime a linha da matriz
printValue :: Row -> IO()
printValue [] = do putStrLn("|")
printValue (((r,c), value):rest) =
  do
    putStr ("| ")
    putStr(id value)
    putStr(" ")
    printValue rest 

printDash :: Int -> [Char] -> IO()
printDash 0 char = do putStrLn(char)
printDash n char =
  do
    putStr(char)
    printDash (n-1) char

-- Converte string para inteiros
stringToInts :: [String] -> [Int]
stringToInts = map read

-- Converte inteiro para strings
intsToString :: [Int] -> String
intsToString = map chr

checkNeighbor :: Pos -> Row -> Row -> Row -> [String]
-- Quando não tem linha antes
checkNeighbor (x,y) [] currentRow rowAfter = 
  do
    let posLeft = (x, y-1)
    let posRight = (x, y+1)
    let posDownLeft = (x-1, y-1)
    let posDown = (x-1, y)
    let posDownRight = (x-1, y+1)
    let neighborLeft = getNeighbor posLeft currentRow
    --let neighborLive = countNeighborLive [left, right, downLeft, down, downRight]
    return "1"
-- Quando não tem linha depois
checkNeighbor (x,y) rowBefore currentRow [] = 
  do
    let posUpLeft = (x+1, y-1)
    let posUp = (x+1,y)
    let posUpRight = (x+1, y+1)
    let posLeft = (x, y-1)
    let posRight = (x, y+1)
    --let neighborLive = countNeighborLive [upLeft, up, upRight, left, right]
    return "1"
checkNeighbor (x,y) rowBefore currentRow rowAfter =
  do
    let posUpLeft = (x+1, y-1)
    let posUp = (x+1,y)
    let posUpRight = (x+1, y+1)
    let posLeft = (x, y-1)
    let posRight = (x, y+1)
    let posDownLeft = (x-1, y-1)
    let posDown = (x-1, y)
    let posDownRight = (x-1, y+1)
    --let neighborLive = countNeighborLive [upLeft, up, upRight, left, right, downLeft, down, downRight]
    return "1"  

getNeighbor :: Pos -> Row -> [String]
getNeighbor (x, y) (((x2, y2), value):rest) =
  do
    let neighbor = if (x == x2 && y == y2)
                   then value
                   else getNeighbor (x, y) rest
    return neighbor

countNeighborLive :: [String] -> Int
countNeighborLive [] = return 0
countNeighborLive [head:rest] =
  do
    let count = if (strEq head "V")
                then 1 + countNeighborLive rest
                else countNeighborLive rest
    return count
  
countNeighborDead :: [String] -> Int
countNeighborDead [] = return 0
countNeighborDead [head:rest] =
  do
    let count = if (strEq head "M")
                then 1 + countNeighborDead rest
                else countNeighborDead rest
    return count

countNeighborZombie :: [String] -> Int
countNeighborZombie [] = return 0
countNeighborZombie [head:rest] =
  do
    let count = if (strEq head "Z")
                then 1 + countNeighborZombie rest
                else countNeighborZombie rest
    return count

main :: IO ()
main = do

  putStrLn ("Tamanho da grid (Ex: 3x2): ")
  gridSize <- getLine
  let gridSizeAsNumber = stringToInts  (splitOn "x" gridSize)

  putStrLn ("Celulas da grid separadas por espaços (V = Viva, M = Morta, Z = Zumbi): ")
  matrix <- initMatrix gridSizeAsNumber

  putStrLn ("Número de iterações máxima: ")
  iteration <- getLine
  let iterationAsNumber = read iteration :: Int

  putStrLn ("Tamanho da grade: " ++ gridSize)

  putStrLn ("Matriz: \n" ++ show matrix)
  putStrLn ("\nTipo da matriz: " ++ show (typeOf matrix))
  -- putStrLn ("Matriz com sort: \n" ++ show (sort (neighbors matrix)))
  putStrLn ("\nPrint criado para matriz:")
  printDash (2*4) "-"
  printMatrix matrix
  printDash (2*4) "-"
  
  putStrLn ("Iteração: " ++ iteration)

  let s  = positions 'L' "foobaraboof"

  putStrLn (show s) 
